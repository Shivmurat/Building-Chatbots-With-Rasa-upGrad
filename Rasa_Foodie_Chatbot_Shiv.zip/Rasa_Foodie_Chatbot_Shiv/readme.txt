rasa --version
Rasa Version     : 2.0.0
Rasa SDK Version : 2.0.0
Rasa X Version   : None
Python Version   : 3.7.6 (default, Jan  8 2020, 13:42:34)
Operating System : Darwin-18.7.0-x86_64-i386-64bit
